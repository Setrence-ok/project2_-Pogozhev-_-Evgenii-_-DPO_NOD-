#!/usr/bin/env python3

from src.primitive_db.engine import welcome


def main():
    welcome()
